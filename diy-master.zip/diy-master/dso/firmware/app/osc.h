#ifndef _OSC_H
#define _OSC_H

void OSC_UpdateParams(void);
void OSC_ParamsUp(void);
void OSC_ParamsDown(void);

#endif
