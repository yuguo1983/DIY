#ifndef _CLI_H
#define _CLI_H

void CLI_Parse(const unsigned char* msg, int size);

#endif
