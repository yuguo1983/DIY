#ifndef _SPI_F1_H
#define _SPI_F1_H

void SPI_Config(void);
void SPI1_Write_DMA(void* buf, int count);

#endif
