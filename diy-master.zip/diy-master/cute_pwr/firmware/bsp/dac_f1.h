#ifndef _DAC_H
#define _DAC_H

#include "misc.h"

void DAC_Config(void);

#endif
