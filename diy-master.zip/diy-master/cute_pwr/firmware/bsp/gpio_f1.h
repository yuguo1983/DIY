#ifndef _GPIO_F1_H
#define _GPIO_F1_H

void GPIO_Config(void);

#endif
