#ifndef _TIMER_H
#define _TIMER_H

#include "misc.h"

void TIMER_Config(void);
void TIMER_SetSamplingRate(int rate);

#endif
