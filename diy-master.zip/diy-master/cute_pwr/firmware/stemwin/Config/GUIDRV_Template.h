#ifndef GUIDRV_TEMPLATE_H
#define GUIDRV_TEMPLATE_H
//
// Addresses
//
extern const GUI_DEVICE_API GUIDRV_Template_API;
//
// Macro to be used in configuration files
//
#define GUIDRV_TEMPLATE            &GUIDRV_Template_API
#endif
