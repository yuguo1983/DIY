#ifndef _DAC_H
#define _DAC_H

void DAC_Config(void);
void DAC_CurrentSet(int curr);

#endif
