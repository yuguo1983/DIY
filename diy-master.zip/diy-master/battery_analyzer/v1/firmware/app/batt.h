#ifndef _BATT_H
#define _BATT_H

void BATT_Parse(const char* msg, int size);
void BATT_ViewVoltage(void);

#endif
