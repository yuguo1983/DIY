#ifndef _KEY_H
#define _KEY_H

void KEY_Config(void);

#endif
