#ifndef _MENU_H
#define _MENU_H

void MENU_Config(void);
void MENU_View(void);
void SELECT_View(void);

#endif
