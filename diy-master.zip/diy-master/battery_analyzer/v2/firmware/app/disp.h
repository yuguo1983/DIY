#ifndef _DISP_H
#define _DISP_H

void DISP_Update(void);
void DISP_Config(void);

#endif
