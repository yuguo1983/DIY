#ifndef _TASKS_H
#define _TASKS_H

void TASKS_Config(void);
void TASKS_Poll(void);

#endif
