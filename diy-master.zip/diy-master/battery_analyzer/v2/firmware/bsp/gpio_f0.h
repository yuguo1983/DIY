#ifndef _GPIO_F0_H
#define _GPIO_F0_H

void GPIO_Config(void);

#endif
