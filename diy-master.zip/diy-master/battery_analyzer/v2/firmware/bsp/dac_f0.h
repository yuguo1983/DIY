#ifndef _DAC_F0_H
#define _DAC_F0_H

#include "misc.h"

void DAC_Config(void);

#endif
