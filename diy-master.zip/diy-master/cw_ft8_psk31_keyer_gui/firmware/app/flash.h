#ifndef _FLASH_H
#define _FLASH_H

void FLASH_Config(void);

#endif
