#ifndef _CLI_H
#define _CLI_H

void CLI_Parse(const void* pmsg, int size, int source);

#endif
