#ifndef _GPIO_F3_H
#define _GPIO_F3_H

void GPIO_Config(void);

#endif
