#ifndef _RTC_F3_H
#define _RTC_F3_H

void RTC_Config(void);
void RTC_GetTimeString(char* string);

#endif
