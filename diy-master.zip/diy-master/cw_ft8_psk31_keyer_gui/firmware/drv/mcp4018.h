#ifndef _MCP4018_H
#define _MCP4018_H

#include "zi2c.h"

void MCP4018_Write(zi2c_t* ps, unsigned char data);

#endif
