#ifndef _DAC_H
#define _DAC_H

void DAC_Config(void);

#endif
