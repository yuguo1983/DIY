#ifndef _TIMER_H
#define _TIMER_H

void TIMER_Config(void);

#endif
