#ifndef _FT8_CBS_H
#define _FT8_CBS_H

void ft8_tx_start(void);
void ft8_tx_char(int c);
void ft8_tx_end(void);
void ft8_tx_symbol(int c);

#endif
