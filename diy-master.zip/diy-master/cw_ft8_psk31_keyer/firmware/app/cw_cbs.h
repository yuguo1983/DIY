#ifndef _CW_CBS_H
#define _CW_CBS_H

void cw_tx_start(void);
void cw_tx_char(int c);
void cw_tx_end(void);
void cw_tx_symbol(int c);

#endif
