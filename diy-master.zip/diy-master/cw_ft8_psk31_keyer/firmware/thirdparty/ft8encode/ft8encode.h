#ifndef _FT8ENCODE_H
#define _FT8ENCODE_H

void ft8_encode(const char* msg, unsigned char * symbols);
int ft8_get_symbol_count(void);

#endif
