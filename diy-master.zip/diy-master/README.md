# DIY

### battery_analyzer

电池放电测试器, 详见 https://zhuanlan.zhihu.com/p/357930070

### cute_pwr

微型数显恒压恒流电源. https://zhuanlan.zhihu.com/p/368384764

### cw_ft8_psk31_keyer

CW/FT8/PSK31三合一调制器 https://zhuanlan.zhihu.com/p/201408443

### dice

用8脚ATTiny13和7个贴片LED做了个骰子. https://zhuanlan.zhihu.com/p/358189317

### dso

DIY示波器, 用STM32F303的内部ADC采样. https://zhuanlan.zhihu.com/p/161459902

### fm_exprs

若干FM发射器实验. https://zhuanlan.zhihu.com/p/372632154

### handy_current

简易手持恒流源, 按键输入所需电流. https://zhuanlan.zhihu.com/p/91693199

### heatbed

PCB预热台, 直接用铜箔作为发热元件, 最高80度, PID控温. https://zhuanlan.zhihu.com/p/345558646

### iambic_keyer

双桨自动键控制器, 带自动连发+交替, 可以自行设置速度. https://zhuanlan.zhihu.com/p/57250391

### lcr

用STM32F303实现的简易LCR, 去掉了硬件鉴相, 改为软件解调, 详见 https://zhuanlan.zhihu.com/p/379264531

### led_cube

简易光立方, 不用搭棚, 而是把PCB做成梳状, 8层梳子叠放实现光立方效果. https://zhuanlan.zhihu.com/p/164646034  https://zhuanlan.zhihu.com/p/209019949
 
### line_follower

简易循线小车(程序有bug待修正) https://zhuanlan.zhihu.com/p/218416625

### nimh_lfp_charger

镍氢/磷酸铁锂自适应充电器 https://zhuanlan.zhihu.com/p/49491177

### rfid_duplicator

小区门禁卡复制器. https://zhuanlan.zhihu.com/p/369332036

### voltmeter_3digi

QFN20的STM8S003+3位数码管实现的简易电压表. https://zhuanlan.zhihu.com/p/301702206

### vs1003_player

用STM32F103+VS1003实现的MP3播放器. https://zhuanlan.zhihu.com/p/48990764

### wav_mp3_player

用STM32F401软解MP3播放, helix库. https://zhuanlan.zhihu.com/p/298500587

