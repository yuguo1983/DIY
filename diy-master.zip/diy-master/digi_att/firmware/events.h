#ifndef _EVENTS_H
#define _EVENTS_H

enum {
    EVENT_KEY0_PRESS,
    EVENT_KEY0_LONGPRESS,
    EVENT_ERROR = -1
};

#endif
