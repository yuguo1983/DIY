#ifndef _REL_H
#define _REL_H

void REL_Config(void);
void REL_Set(int rel_id, int state);

#endif
