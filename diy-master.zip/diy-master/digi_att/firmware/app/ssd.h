#ifndef _SSD_H
#define _SSD_H

void SSD_Config(void);

#endif
