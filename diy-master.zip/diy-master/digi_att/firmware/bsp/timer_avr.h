#ifndef _TIMER_AVR_H
#define _TIMER_AVR_H

void TIMER_Config(void);

#endif
